<div class="register">
  <form class="form-signin shadow mt-2">
    <div class="w-100 text-center">
      <img class="mb-4" src="login.png" alt="" width="72" height="72">
    </div>
    <h1 class="h3 mb-3 font-weight-normal">Please sign up</h1>

    <label for="username">Username</label>
    <input type="username" id="username" onblur="vrfUsername(this)" name="username" class="form-control" placeholder="Username" required autofocus>

    <label for="email">Email address</label>
    <input type="email" id="email" onblur="vrfEmail(this)" name="email" class="form-control" placeholder="Email address" required autofocus>

    <label for="passw">Password</label>
    <input type="password" id="passw" name="password" class="form-control" placeholder="Password" required>

    <input class="btn btn-lg btn-primary btn-block" onclick="newUser()" type="button" value="Sign up"></button>

  </form>
  <div class="msg"></div>
</div>
<hr>

<script>
  let user = {
    username: false,
    email: false
  }

  function vrfUsername(obj) {
    console.log('vrfUsername-', obj.value)
    verifyUser('../server/verifyUser.php?username=' + obj.value, renderVryUsername);
  }

  function renderVryUsername(data) {
    console.log(data)
    if (data.nr == 0)
      user.username = true
    else
      user.username = false
  }

  function vrfEmail(obj) {
    console.log(obj.value)
    verifyUser('../server/verifyUser.php?email=' + obj.value, renderVryEmail);
  }

  function renderVryEmail(data) {
    console.log(data)
    if (data.nr == 0)
      user.email = true
    else
      user.email = false
  }
 function newUser() {
    if (user.username && user.email) {
      const myFormData = new FormData(document.querySelector('form'));
      /*for(let obj of myFormData){
        console.log(obj);
      }*/
      let configObj = {
        method: 'POST',
        body: myFormData
      }
      postData('../server/insertuser.php', configObj, render)
    }

    function render(data) {
      console.log("render-data:",data);
      document.querySelector('.msg').innerHTML = data.msg;
      if(data?.id){
        user.username=false
        user.email=false
      }

    }

  }
</script>