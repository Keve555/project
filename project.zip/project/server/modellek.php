<?php
require_once "db.php";
extract($_GET);
$sql="";
$stmt=$db->query($sql);
echo json_encode($stmt->fetchAll());
?>