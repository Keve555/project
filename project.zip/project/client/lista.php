<h1>Listák</h1>
<table>
    <thead>
        <tr>
            <td>Név</td>
            <td>Ország</td>
            <td>Székhely</td>
            <td>Alapítási év</td>
        </tr>
    </thead>
    <tbody id="lista"></tbody>
</table>
<script src="data.js"></script>
<script>
    data("../server/lista.php",render)
    function render(data){
        console.log(data)
        let str=""
        for(let obj of data)
        str+=`
        <tr>
            <td>${obj.nev}</td>
            <td>${obj.orszag}</td>
            <td>${obj.szekhely}</td>
            <td>${obj.alapitasiev}</td>
        </tr>
        `
        document.getElementById("lista").innerHTML=str
    }
</script>