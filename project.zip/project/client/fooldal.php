<div style="padding-left:16px">
    <h1>Autómárkák</h1>
    <h3>Amit az autókról nem tudtál.</h3>
</div>
<!--<footer>
    <p id="lablec">Forrás</p>
    <p id="lablec">Adatvédelmi irányelvek</p>
</footer>-->