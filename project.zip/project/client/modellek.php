<h1>Modellek</h1>
<table>
    <thead>
        <tr>
            <td></td>
        </tr>
    </thead>
    <tbody id="lista"></tbody>
</table>
<script src="data.js"></script>
<script>
    data("../server/lista.php",render)
    function render(data){
        console.log(data)
        let str=""
        for(let obj of data)
        str+=`
        <tr>
            <td>${obj}</td>
            <td>${obj}</td>
        </tr>
        `
        document.getElementById("lista").innerHTML=str
    }
</script>